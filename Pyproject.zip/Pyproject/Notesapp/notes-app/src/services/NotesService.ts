class NotesService {
    private notes: Note[] = [];

    getAllNotes(): Note[] {
        return this.notes;
    }

    addNote(note: Note): void {
        this.notes.push(note);
    }

    deleteNote(id: string): void {
        this.notes = this.notes.filter(note => note.id !== id);
    }
}