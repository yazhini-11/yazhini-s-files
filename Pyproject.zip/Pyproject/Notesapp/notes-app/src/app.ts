import { NotesService } from './services/NotesService';
import { Note } from './types';

class App {
    private notesService: NotesService;

    constructor() {
        this.notesService = new NotesService();
        this.initialize();
    }

    private initialize(): void {
        console.log('Initializing Notes App...');
        this.loadNotes();
    }

    private loadNotes(): void {
        const notes: Note[] = this.notesService.getAllNotes();
        console.log('Loaded Notes:', notes);
    }
}

const app = new App();