class Note {
    title: string;
    content: string;

    constructor(title: string, content: string) {
        this.title = title;
        this.content = content;
    }

    save(): void {
        // Logic to save the note
    }

    delete(): void {
        // Logic to delete the note
    }
}

export default Note;