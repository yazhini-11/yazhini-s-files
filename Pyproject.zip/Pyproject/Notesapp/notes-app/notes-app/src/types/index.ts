export interface NoteInterface {
    title: string;
    content: string;
}