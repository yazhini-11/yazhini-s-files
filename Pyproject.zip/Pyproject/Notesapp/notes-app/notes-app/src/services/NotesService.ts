class Note {
    title: string;
    content: string;

    constructor(title: string, content: string) {
        this.title = title;
        this.content = content;
    }

    getSummary(): string {
        return this.content.length > 50 ? this.content.substring(0, 50) + '...' : this.content;
    }

    getDetails(): string {
        return `Title: ${this.title}\nContent: ${this.content}`;
    }
}

export class NotesService {
    private notes: Note[] = [];
    private nextId: number = 1;

    addNote(note: Note): void {
        this.notes.push(note);
    }

    getNotes(): Note[] {
        return this.notes;
    }

    deleteNote(id: string): void {
        this.notes = this.notes.filter((note, index) => index.toString() !== id);
    }
}