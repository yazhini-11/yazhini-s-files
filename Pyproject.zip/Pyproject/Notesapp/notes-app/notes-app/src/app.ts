import express from 'express';
import bodyParser from 'body-parser';
import { NotesService } from './services/NotesService';

const app = express();
const port = process.env.PORT || 3000;
const notesService = new NotesService();

app.use(bodyParser.json());

app.post('/notes', (req, res) => {
    const { title, content } = req.body;
    const note = notesService.addNote({ title, content });
    res.status(201).json(note);
});

app.get('/notes', (req, res) => {
    const notes = notesService.getNotes();
    res.json(notes);
});

app.delete('/notes/:id', (req, res) => {
    const { id } = req.params;
    notesService.deleteNote(id);
    res.status(204).send();
});

app.listen(port, () => {
    console.log(`Notes app listening at http://localhost:${port}`);
});