# Notes Application

This is a simple notes application built with TypeScript. It allows users to create, view, and delete notes.

## Project Structure

```
notes-app
├── src
│   ├── app.ts               # Entry point of the application
│   ├── components
│   │   └── Note.ts          # Note component with properties and methods
│   ├── services
│   │   └── NotesService.ts   # Service for managing notes
│   └── types
│       └── index.ts         # Type definitions for the application
├── package.json              # npm configuration file
├── tsconfig.json             # TypeScript configuration file
└── README.md                 # Project documentation
```

## Setup Instructions

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd notes-app
   ```

3. Install the dependencies:
   ```
   npm install
   ```

4. Compile the TypeScript files:
   ```
   npm run build
   ```

5. Run the application:
   ```
   npm start
   ```

## Usage Guidelines

- To create a new note, use the `addNote` method from the `NotesService`.
- To retrieve all notes, call the `getNotes` method.
- To delete a note, use the `deleteNote` method with the note's ID.

## Contributing

Feel free to submit issues or pull requests for improvements or bug fixes.